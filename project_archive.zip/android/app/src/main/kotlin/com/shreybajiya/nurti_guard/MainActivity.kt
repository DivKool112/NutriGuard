package com.shreybajiya.nurti_guard

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
