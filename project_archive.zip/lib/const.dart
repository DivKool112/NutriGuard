import 'dart:ui';

Color priColor = Color.fromRGBO(20, 186, 70, 1);
Color darkGreen = Color(0xff009963);
Color grey = Color(0xff14181b);
Color golColor = Color(0xffA1824A);
